import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const ProtectedRoute = ({ allowedRoles }) => {
    const { user, isLoading } = useAuth();

    // Поки перевіряємо токен з localStorage, показуємо екран завантаження
    if (isLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-gray-500 font-medium">Перевірка прав доступу...</div>
            </div>
        );
    }

    const userRole = user?.role || 'Незареєстрований';

    // Якщо користувач не авторизований взагалі, відправляємо на логін
    if (!user && allowedRoles.length > 0) {
        return <Navigate to="/login" replace />;
    }

    // Якщо авторизований, але роль не підходить, відправляємо на головну
    if (!allowedRoles.includes(userRole)) {
        return <Navigate to="/" replace />;
    }

    // Якщо все добре, рендеримо дочірній компонент
    return <Outlet />;
};

export default ProtectedRoute;
