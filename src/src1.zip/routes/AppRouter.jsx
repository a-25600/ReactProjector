import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

// Layout
import MainLayout from '../layouts/MainLayout';
import ProtectedRoute from './ProtectedRoute';

// Публічні сторінки (Auth & Головна)
import Home from '../pages/Home/Home';
import Login from '../pages/Auth/Login';
import Register from '../pages/Auth/Register';

// Новини
import Category from '../pages/News/Category';
import Article from '../pages/News/Article';

// Медіа та Блоги
import PodcastPage from '../pages/Podcasts/PodcastPage';
import BlogList from '../pages/Blogs/BlogList';
import BlogPost from '../pages/Blogs/BlogPost';

// Форум
import ForumHome from '../pages/Forum/ForumHome';
import ForumThread from '../pages/Forum/ForumThread';

// Приватні сторінки (для авторизованих)
import UserProfile from '../pages/Profile/UserProfile';

// Робочі кабінети (для працівників та адміністрації)
import JournalistWorkspace from '../pages/Admin/JournalistWorkspace';
import AuthorWorkspace from '../pages/Admin/AuthorWorkspace';
import ModeratorDashboard from '../pages/Admin/ModeratorDashboard';
import AdminDashboard from '../pages/Admin/AdminDashboard';

const AppRouter = () => {
    return (
        <BrowserRouter>
            <Routes>
                {/* Всі сторінки обгорнуті в MainLayout (мають шапку і підвал) */}
                <Route element={<MainLayout />}>

                    {/* ============================== */}
                    {/* 1. ПУБЛІЧНІ МАРШРУТИ           */}
                    {/* ============================== */}
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />

                    <Route path="/category/:categoryId" element={<Category />} />
                    <Route path="/news/:id" element={<Article />} />

                    <Route path="/podcasts" element={<PodcastPage />} />
                    <Route path="/blogs" element={<BlogList />} />
                    <Route path="/blogs/:id" element={<BlogPost />} />

                    <Route path="/forum" element={<ForumHome />} />
                    <Route path="/forum/:id" element={<ForumThread />} />


                    {/* ============================== */}
                    {/* 2. ПРИВАТНІ МАРШРУТИ (Читачі)  */}
                    {/* ============================== */}
                    <Route element={<ProtectedRoute allowedRoles={['Зареєстрований', 'Журналіст', 'Запрошений автор', 'Модератор', 'Адміністратор']} />}>
                        <Route path="/profile" element={<UserProfile />} />
                    </Route>


                    {/* ============================== */}
                    {/* 3. РОБОЧІ КАБІНЕТИ (Персонал)  */}
                    {/* ============================== */}

                    {/* Кабінет Журналіста (Публікація новин на модерацію) */}
                    <Route element={<ProtectedRoute allowedRoles={['Журналіст', 'Адміністратор']} />}>
                        <Route path="/journalist-workspace" element={<JournalistWorkspace />} />
                    </Route>

                    {/* Кабінет Автора (Публікація в розділ "Блоги") */}
                    <Route element={<ProtectedRoute allowedRoles={['Запрошений автор', 'Адміністратор']} />}>
                        <Route path="/author-workspace" element={<AuthorWorkspace />} />
                    </Route>

                    {/* Кабінет Модератора (Схвалення новин та користувачів) */}
                    <Route element={<ProtectedRoute allowedRoles={['Модератор', 'Адміністратор']} />}>
                        <Route path="/moderator" element={<ModeratorDashboard />} />
                    </Route>

                    {/* Панель Адміністратора (Управління ролями та статистика) */}
                    <Route element={<ProtectedRoute allowedRoles={['Адміністратор']} />}>
                        <Route path="/admin" element={<AdminDashboard />} />
                    </Route>

                </Route>
            </Routes>
        </BrowserRouter>
    );
};

export default AppRouter;
