import React from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { usePermissions } from '../hooks/usePermissions';

const MainLayout = () => {
    const { user, logout } = useAuth();
    const { canAccessAdminPanel, canModerateComments, canWriteBlog, canAddNews } = usePermissions();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/');
    };

    return (
        <div className="min-h-screen flex flex-col bg-gray-50 font-sans">
            {/* Шапка сайту (Header) */}
            <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">

                    {/* Логотип та основна навігація */}
                    <div className="flex items-center gap-8">
                        <Link to="/" className="text-2xl font-black text-blue-600 tracking-tighter">
                            PROJECTOR<span className="text-gray-900">.media</span>
                        </Link>

                        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600">
                            <Link to="/category/actual" className="hover:text-blue-600 transition-colors">Новини</Link>
                            <Link to="/podcasts" className="hover:text-blue-600 transition-colors">Подкасти</Link>
                            <Link to="/blogs" className="hover:text-blue-600 transition-colors">Блоги</Link>
                            <Link to="/forum" className="hover:text-blue-600 transition-colors">Форум</Link>
                        </nav>
                    </div>

                    {/* Права частина: Авторизація та Спец. панелі */}
                    <div className="flex items-center gap-4 text-sm">
                        {user ? (
                            <div className="flex items-center gap-4">
                                {/* Динамічні посилання залежно від ролі */}
                                {canAccessAdminPanel && (
                                    <Link to="/admin" className="hidden lg:block text-purple-600 font-bold hover:underline">Адмін-панель</Link>
                                )}
                                {canModerateComments && !canAccessAdminPanel && (
                                    <Link to="/moderator" className="hidden lg:block text-blue-600 font-bold hover:underline">Модерація</Link>
                                )}
                                {canAddNews && !canModerateComments && (
                                    <Link to="/journalist-workspace" className="hidden lg:block text-green-600 font-bold hover:underline">Кабінет Журналіста</Link>
                                )}
                                {canWriteBlog && user.role === 'Запрошений автор' && (
                                    <Link to="/author-workspace" className="hidden lg:block text-orange-600 font-bold hover:underline">Кабінет Автора</Link>
                                )}

                                <div className="h-6 w-px bg-gray-300 hidden md:block"></div>

                                <Link to="/profile" className="font-semibold text-gray-800 hover:text-blue-600 flex items-center gap-2">
                                    <div className="w-8 h-8 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center font-bold">
                                        {user.name.charAt(0).toUpperCase()}
                                    </div>
                                    <span className="hidden md:block">{user.name}</span>
                                </Link>

                                <button onClick={handleLogout} className="text-gray-500 hover:text-red-600 transition-colors">
                                    Вийти
                                </button>
                            </div>
                        ) : (
                            <div className="flex items-center gap-3">
                                <Link to="/login" className="text-gray-600 font-medium hover:text-blue-600 transition-colors">Увійти</Link>
                                <Link to="/register" className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors">
                                    Підписатися
                                </Link>
                            </div>
                        )}
                    </div>
                </div>
            </header>

            {/* Основний контент (сюди підставлятимуться сторінки з AppRouter) */}
            <main className="flex-grow">
                <Outlet />
            </main>

            {/* Підвал сайту (Footer) */}
            <footer className="bg-gray-900 text-white py-12 mt-auto">
                <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div className="col-span-1 md:col-span-2">
                        <h3 className="text-2xl font-black tracking-tighter mb-4">PROJECTOR.</h3>
                        <p className="text-gray-400 text-sm max-w-sm">
                            Сучасне медіа про культуру, технології та життя міста. Незалежний погляд, глибока аналітика та платформа для обговорень.
                        </p>
                    </div>
                    <div>
                        <h4 className="font-bold mb-4 uppercase text-sm text-gray-300 tracking-wider">Рубрики</h4>
                        <ul className="space-y-2 text-sm text-gray-400">
                            <li><Link to="/category/actual" className="hover:text-white transition-colors">Актуальні події</Link></li>
                            <li><Link to="/category/culture" className="hover:text-white transition-colors">Культура</Link></li>
                            <li><Link to="/category/regions" className="hover:text-white transition-colors">Регіони</Link></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold mb-4 uppercase text-sm text-gray-300 tracking-wider">Про нас</h4>
                        <ul className="space-y-2 text-sm text-gray-400">
                            <li><Link to="/about" className="hover:text-white transition-colors">Редакція</Link></li>
                            <li><Link to="/rules" className="hover:text-white transition-colors">Правила форуму</Link></li>
                            <li><Link to="/contacts" className="hover:text-white transition-colors">Контакти</Link></li>
                        </ul>
                    </div>
                </div>
                <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-gray-800 text-sm text-gray-500 text-center">
                    © 2026 Projector Media. Усі права захищено.
                </div>
            </footer>
        </div>
    );
};

export default MainLayout;
