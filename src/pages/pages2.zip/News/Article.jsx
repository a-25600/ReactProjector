import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import PollWidget from '../../components/Widgets/PollWidget'; // Твій відремонтований віджет

const Article = () => {
  // Отримуємо ID статті з URL (наприклад, з /article/5 отримаємо "5")
  const { id } = useParams();

  // Стан для збереження реальної статті з БД
  const [article, setArticle] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

  useEffect(() => {
    const fetchArticle = async () => {
      try {
        // Робимо GET-запит до твого C# контролера
        const response = await fetch(`${API_URL}/news/${id}`);

        if (!response.ok) {
          throw new Error('Статтю не знайдено або вона ще не пройшла модерацію');
        }

        const data = await response.json();
        setArticle(data); // Зберігаємо отриману статтю в стейт
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchArticle();
  }, [id, API_URL]);

  // Відображення під час завантаження
  if (isLoading) {
    return <div className="max-w-4xl mx-auto py-20 text-center text-gray-500 font-bold">Завантаження матеріалу...</div>;
  }

  // Відображення помилки (наприклад, якщо ввели неправильний ID)
  if (error) {
    return (
      <div className="max-w-4xl mx-auto py-20 text-center">
        <h2 className="text-2xl font-bold text-red-600 mb-4">{error}</h2>
        <Link to="/" className="text-brand-blue hover:underline">Повернутися на головну</Link>
      </div>
    );
  }

  // Якщо статті немає (перестраховка)
  if (!article) return null;

  // Форматування дати
  const formattedDate = new Date(article.date).toLocaleDateString('uk-UA', {
    year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  return (
    <article className="max-w-4xl mx-auto py-10 px-4">
      {/* Шапка статті */}
      <header className="mb-8 border-b border-gray-200 pb-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="bg-brand-blue text-white px-3 py-1 text-xs font-bold rounded-md uppercase tracking-wider">
            {article.category}
          </span>
          <time className="text-sm text-gray-500">{formattedDate}</time>
        </div>

        <h1 className="text-4xl md:text-5xl font-black text-brand-dark leading-tight mb-4">
          {article.title}
        </h1>

        {/* Лід (короткий опис) */}
        <p className="text-xl text-gray-600 font-medium leading-relaxed italic">
          {article.previewText}
        </p>

        <div className="mt-4 text-sm font-bold text-gray-800">
          Автор: <span className="text-brand-blue">{article.author || 'Редакція'}</span>
        </div>
      </header>

      {/* Зображення статті */}
      {article.imageUrl && (
        <div className="mb-10 rounded-2xl overflow-hidden shadow-md">
          <img
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-auto object-cover max-h-[500px]"
            onError={(e) => { e.target.style.display = 'none' }} // Приховуємо, якщо лінк битий
          />
        </div>
      )}

      {/* Основний текст */}
      <div className="prose prose-lg max-w-none text-gray-800 leading-relaxed mb-12 whitespace-pre-wrap">
        {article.fullText}
      </div>

      {/* Віджет опитування, який ти полагодив */}
      <div className="bg-gray-50 p-6 rounded-2xl border border-gray-200">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Думка читачів</h3>
        <PollWidget />
      </div>
    </article>
  );
};

export default Article;
