import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import CategoryNav from '../../components/News/CategoryNav';
import NewsCard from '../../components/News/NewsCard';
import AdBanner from '../../components/Widgets/AdBanner';
import PodcastPlayer from '../../components/Media/PodcastPlayer';
import PostOfTheDay from '../../components/Media/PostOfTheDay';

const Home = () => {
    const [activeCategory, setActiveCategory] = useState('Актуальні події');

    const [news, setNews] = useState([]);
    const [latestPodcast, setLatestPodcast] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    const navigate = useNavigate();
    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

    useEffect(() => {
        const fetchHomeData = async () => {
            setIsLoading(true);
            try {
                const [newsRes, podcastRes] = await Promise.all([
                    fetch(`${API_URL}/news?category=${encodeURIComponent(activeCategory)}&limit=4`),
                    fetch(`${API_URL}/podcasts/latest`)
                ]);

                if (newsRes.ok) setNews(await newsRes.json());
                if (podcastRes.ok) setLatestPodcast(await podcastRes.json());
            } catch (error) {
                console.error("Помилка завантаження даних головної сторінки:", error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchHomeData();
    }, [activeCategory, API_URL]);

    return (
        <div className="max-w-7xl mx-auto py-8 px-4 grid grid-cols-1 lg:grid-cols-3 gap-8 font-sans">
            <main className="lg:col-span-2 space-y-8">
                <div className="border-b border-gray-200 pb-4">
                    <h1 className="text-3xl font-black text-brand-dark tracking-tight mb-4">Головні публікації</h1>
                    <CategoryNav activeCategory={activeCategory} onSelectCategory={setActiveCategory} />
                </div>

                {isLoading ? (
                    <div className="text-center py-20 text-gray-500 animate-pulse">Завантаження стрічки...</div>
                ) : (
                    <>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {news.map(item => (
                                <NewsCard
                                    key={item.id}
                                    title={item.title}
                                    date={item.date}
                                    category={item.category}
                                    imageUrl={item.imageUrl}
                                    onClick={() => navigate(`/news/${item.id}`)}
                                />
                            ))}
                        </div>

                        {latestPodcast && (
                            <div className="pt-4 border-t border-gray-100 mt-6">
                                <h3 className="text-lg font-bold text-brand-dark mb-3">Слухати зараз</h3>
                                <PodcastPlayer
                                    title={latestPodcast.title}
                                    audioUrl={latestPodcast.audioUrl}
                                />
                            </div>
                        )}
                    </>
                )}
            </main>

            <aside className="lg:col-span-1 space-y-6">
                <AdBanner onMoreClick={() => navigate('/category/actual')} />
                <PostOfTheDay
                    source="Instagram"
                    author="@projector_media"
                    text="Слідкуйте за оновленнями у соцмережах!"
                />
            </aside>
        </div>
    );
};

export default Home;
