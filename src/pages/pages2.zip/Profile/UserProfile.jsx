import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

const UserProfile = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    
    const [emailNotifications, setEmailNotifications] = useState(true);
    const [smartBandMode, setSmartBandMode] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    const [message, setMessage] = useState({ text: '', type: '' });

    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

    if (!user) {
        return <div className="text-center py-20">Будь ласка, увійдіть у систему.</div>;
    }

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const saveSettings = async () => {
        setIsSaving(true);
        setMessage({ text: '', type: '' });

        try {
            const token = localStorage.getItem('token');

            const response = await fetch(`${API_URL}/users/settings`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    emailNotifications,
                    smartBandMode
                })
            });

            if (!response.ok) {
                throw new Error('Не вдалося зберегти налаштування. Спробуйте пізніше.');
            }

            setMessage({ text: 'Налаштування успішно збережено!', type: 'success' });

        } catch (error) {
            setMessage({ text: error.message, type: 'error' });
        } finally {
            setIsSaving(false);

            setTimeout(() => setMessage({ text: '', type: '' }), 3000);
        }
    };

    return (
        <div className="max-w-4xl mx-auto py-10 px-4">
            <div className="flex justify-between items-end mb-8 border-b border-gray-200 pb-4">
                <div>
                    <h1 className="text-3xl font-black text-gray-900">Особистий кабінет</h1>
                    <p className="text-gray-500 mt-1">Керування профілем та підписками</p>
                </div>
                <button
                    onClick={handleLogout}
                    className="text-red-600 font-medium hover:underline text-sm"
                >
                    Вийти з акаунта
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-1 space-y-6">
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                        <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-2xl font-bold mb-4">
                            {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                        </div>
                        <h2 className="text-xl font-bold text-gray-900">{user.name}</h2>
                        <p className="text-gray-500 text-sm mb-4">{user.email}</p>
                        <div className="inline-block px-3 py-1 bg-gray-100 text-gray-700 text-xs font-bold rounded">
                            Роль: {user.role}
                        </div>
                    </div>

                    <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-xl text-white shadow-md">
                        <h3 className="font-bold mb-2 flex items-center gap-2">
                            <span>⭐</span> Ексклюзивний доступ
                        </h3>
                        <p className="text-xs text-gray-300 mb-4">
                            У вас немає активної платної підписки. Отримайте доступ до аналітичних лонгрідів та закритих обговорень.
                        </p>
                        <button className="w-full bg-blue-600 hover:bg-blue-500 text-white font-medium py-2 rounded transition-colors text-sm">
                            Оформити підписку
                        </button>
                    </div>
                </div>

                <div className="md:col-span-2">
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                        <h3 className="text-lg font-bold text-gray-900 mb-6">Налаштування застосунку</h3>

                        <div className="space-y-5">
                            <div className="flex items-center justify-between py-3 border-b border-gray-100">
                                <div>
                                    <p className="font-medium text-gray-800">Email-розсилка новин</p>
                                    <p className="text-xs text-gray-500">Отримувати головні матеріали дня на пошту</p>
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input
                                        type="checkbox"
                                        className="sr-only peer"
                                        checked={emailNotifications}
                                        onChange={() => setEmailNotifications(!emailNotifications)}
                                    />
                                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                </label>
                            </div>

                            <div className="flex items-center justify-between py-3 border-b border-gray-100">
                                <div>
                                    <p className="font-medium text-gray-800">Фонове відтворення (Економія енергії)</p>
                                    <p className="text-xs text-gray-500">Оптимізація аудіо-начитки та подкастів під час активної ходьби (напр. під час використання фітнес-браслетів)</p>
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input
                                        type="checkbox"
                                        className="sr-only peer"
                                        checked={smartBandMode}
                                        onChange={() => setSmartBandMode(!smartBandMode)}
                                    />
                                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                </label>
                            </div>
                        </div>

                        <div className="mt-8 flex items-center justify-end gap-4">
                            {message.text && (
                                <span className={`text-sm ${message.type === 'success' ? 'text-green-600' : 'text-red-600'}`}>
                                    {message.text}
                                </span>
                            )}

                            <button
                                onClick={saveSettings}
                                disabled={isSaving}
                                className="bg-gray-900 text-white px-6 py-2 rounded hover:bg-gray-800 transition-colors disabled:bg-gray-500 font-medium"
                            >
                                {isSaving ? 'Збереження...' : 'Зберегти зміни'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default UserProfile;
