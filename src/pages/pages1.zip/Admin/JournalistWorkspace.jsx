import React, { useState } from 'react';

const JournalistWorkspace = () => {
    const [title, setTitle] = useState('');
    const [category, setCategory] = useState('Політика');
    const [tags, setTags] = useState('');
    const [content, setContent] = useState('');

    const [status, setStatus] = useState('idle');
    const [message, setMessage] = useState('');

    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

    const handleSubmit = async (e) => {
        e.preventDefault();
        setStatus('loading');
        setMessage('');

        try {
            const token = localStorage.getItem('token');

            const response = await fetch(`${API_URL}/articles`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    title,
                    category,
                    tags: tags.split(',').map(tag => tag.trim()),
                    content
                })
            });

            if (!response.ok) {
                throw new Error('Не вдалося зберегти статтю');
            }

            setStatus('success');
            setMessage(`Новину "${title}" успішно відправлено на модерацію!`);

            setTitle('');
            setCategory('Актуальні події');
            setTags('');
            setContent('');

            setTimeout(() => setStatus('idle'), 5000);
        } catch (error) {
            setStatus('error');
            setMessage(error.message);
        }
    };

    return (
        <div className="max-w-4xl mx-auto py-8">
            <h1 className="text-3xl font-black text-gray-900 mb-2">Кабінет Журналіста</h1>
            <p className="text-gray-500 mb-8">Створення нового матеріалу. Після збереження стаття буде відправлена модератору.</p>

            {status === 'success' && <div className="bg-green-50 text-green-700 p-4 rounded mb-6 border border-green-200">{message}</div>}
            {status === 'error' && <div className="bg-red-50 text-red-600 p-4 rounded mb-6 border border-red-200">{message}</div>}

            <form onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 space-y-6">
                <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Заголовок новини</label>
                    <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        required
                        className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:outline-none text-lg"
                    />
                </div>

                <div className="grid grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Рубрика</label>
                        <select
                            value={category}
                            onChange={(e) => setCategory(e.target.value)}
                            className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 bg-white"
                        >
                            <option value="Політика">Політика</option>
                            <option value="Економіка">Економіка</option>
                            <option value="Технології">Технології</option>
                            <option value="Спорт">Спорт</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-bold text-gray-700 mb-2">Теги (через кому)</label>
                        <input
                            type="text"
                            value={tags}
                            onChange={(e) => setTags(e.target.value)}
                            className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:outline-none"
                            placeholder="IT, бюджет, закон"
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Текст статті</label>
                    <textarea
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        required
                        rows="12"
                        className="w-full p-3 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500 focus:outline-none resize-y"
                    />
                </div>

                <div className="flex justify-end pt-4 border-t border-gray-200">
                    <button
                        type="submit"
                        disabled={status === 'loading'}
                        className="bg-gray-900 text-white px-8 py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:bg-gray-500"
                    >
                        {status === 'loading' ? 'Відправка...' : 'Відправити на модерацію'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default JournalistWorkspace;
