import React, { useState, useEffect } from 'react';

const ModeratorDashboard = () => {
    const [activeTab, setActiveTab] = useState('users');
    const [pendingUsers, setPendingUsers] = useState([]);
    const [pendingArticles, setPendingArticles] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
    const token = localStorage.getItem('token');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [usersRes, articlesRes] = await Promise.all([
                    fetch(`${API_URL}/moderation/users`, { headers: { 'Authorization': `Bearer ${token}` } }),
                    fetch(`${API_URL}/moderation/articles`, { headers: { 'Authorization': `Bearer ${token}` } })
                ]);

                if (usersRes.ok) setPendingUsers(await usersRes.json());
                if (articlesRes.ok) setPendingArticles(await articlesRes.json());
            } catch (error) {
                console.error("Помилка завантаження даних для модерації:", error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, [API_URL, token]);

    const handleApproveUser = async (id) => {
        try {
            const response = await fetch(`${API_URL}/moderation/users/${id}/approve`, {
                method: 'PUT',
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (response.ok) {
                setPendingUsers(pendingUsers.filter(user => user.id !== id));
                alert('Користувача успішно схвалено!');
            } else {
                alert('Помилка сервера під час схвалення користувача.');
            }
        } catch (error) {
            alert('Помилка при схваленні користувача.');
        }
    };

    const handleApproveArticle = async (id) => {
        try {
            const response = await fetch(`${API_URL}/moderation/articles/${id}/approve`, {
                method: 'PUT',
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (response.ok) {
                setPendingArticles(pendingArticles.filter(article => article.id !== id));
                alert('Статтю успішно опубліковано на сайті!');
            } else {
                alert('Помилка сервера під час схвалення статті.');
            }
        } catch (error) {
            alert('Помилка при схваленні статті.');
        }
    };
    const handleRejectArticle = async (id) => {
        if (window.confirm('Ви впевнені, що хочете відхилити цю статтю?')) {
            try {
                const response = await fetch(`${API_URL}/moderation/articles/${id}`, {
                    method: 'DELETE',
                    headers: { 'Authorization': `Bearer ${token}` }
                });

                if (response.ok) {
                    setPendingArticles(pendingArticles.filter(article => article.id !== id));
                }
            } catch (error) {
                console.error('Помилка видалення', error);
            }
        }
    };

    if (isLoading) return <div className="text-center py-20 text-gray-500">Завантаження панелі...</div>;

    return (
        <div className="max-w-6xl mx-auto py-8 px-4">
            <h1 className="text-3xl font-black text-gray-900 mb-8">Панель Модератора</h1>

            <div className="flex space-x-4 mb-6 border-b border-gray-200">
                <button
                    onClick={() => setActiveTab('users')}
                    className={`pb-3 px-2 text-sm font-medium transition-colors ${activeTab === 'users' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-500 hover:text-gray-800'}`}
                >
                    Заявки на реєстрацію ({pendingUsers.length})
                </button>
                <button
                    onClick={() => setActiveTab('articles')}
                    className={`pb-3 px-2 text-sm font-medium transition-colors ${activeTab === 'articles' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-500 hover:text-gray-800'}`}
                >
                    Новини на перевірці ({pendingArticles.length})
                </button>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                {activeTab === 'users' && (
                    <div>
                        {pendingUsers.length === 0 ? <p className="text-gray-500">Немає нових заявок на реєстрацію.</p> : (
                            <div className="space-y-4">
                                {pendingUsers.map(user => (
                                    <div key={user.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                                        <div className="mb-3 sm:mb-0">
                                            <p className="font-semibold text-gray-900">{user.name} <span className="text-sm font-normal text-gray-500">({user.email})</span></p>
                                            <p className="text-sm text-blue-600 mt-1 font-medium">Бажана роль: {user.requestedRole}</p>
                                        </div>
                                        <button onClick={() => handleApproveUser(user.id)} className="px-6 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors w-full sm:w-auto">
                                            Схвалити
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {activeTab === 'articles' && (
                    <div>
                        {pendingArticles.length === 0 ? <p className="text-gray-500">Немає нових статей на модерації.</p> : (
                            <div className="space-y-4">
                                {pendingArticles.map(article => (
                                    <div key={article.id} className="flex flex-col md:flex-row md:items-center justify-between p-5 bg-gray-50 rounded-lg border border-gray-100">

                                        <div className="mb-4 md:mb-0">
                                            <h3 className="font-bold text-gray-900 text-lg mb-2 leading-tight">{article.title}</h3>
                                            <div className="flex flex-wrap items-center gap-3">
                                                <span className="px-2.5 py-1 bg-blue-100 text-blue-800 text-xs font-bold rounded uppercase tracking-wider">
                                                    {article.category}
                                                </span>
                                                <span className="text-sm text-gray-600">Автор: <span className="font-medium text-gray-800">{article.author}</span></span>
                                                <span className="text-sm text-gray-500">{article.date}</span>
                                            </div>
                                        </div>

                                        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 shrink-0">
                                            <button
                                                onClick={() => handleRejectArticle(article.id)}
                                                className="px-5 py-2 bg-red-50 text-red-600 border border-red-200 text-sm font-medium rounded-lg hover:bg-red-100 transition-colors"
                                            >
                                                Відхилити
                                            </button>
                                            <button
                                                className="px-5 py-2 bg-white border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-100 transition-colors"
                                            >
                                                Читати
                                            </button>
                                            <button
                                                onClick={() => handleApproveArticle(article.id)}
                                                className="px-5 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 transition-colors shadow-sm"
                                            >
                                                Опублікувати
                                            </button>
                                        </div>

                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}

            </div>
        </div>
    );
};

export default ModeratorDashboard;
