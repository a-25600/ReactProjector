import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

const AdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [usersList, setUsersList] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

  // Завантаження списку користувачів
  useEffect(() => {
    // Додаткова перевірка на фронтенді (хоча бекенд теж захищений)
    if (!user || user.role !== 'Адміністратор') {
      navigate('/');
      return;
    }

    const fetchUsers = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await fetch(`${API_URL}/admin/users`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        if (response.ok) {
          const data = await response.json();
          setUsersList(data);
        } else {
          throw new Error('Не вдалося завантажити користувачів');
        }
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUsers();
  }, [user, navigate, API_URL]);

  // Обробник для схвалення та зміни ролі
  const handleApprove = async (id, newRole) => {
    const token = localStorage.getItem('token');
    try {
      const response = await fetch(`${API_URL}/admin/users/${id}/approve`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ role: newRole })
      });

      if (response.ok) {
        // Оновлюємо список локально, щоб не робити ще один запит до БД
        setUsersList(usersList.map(u =>
          u.id === id ? { ...u, isApproved: true, role: newRole } : u
        ));
      } else {
        alert('Помилка при схваленні');
      }
    } catch (error) {
      console.error(error);
      alert('Помилка з\'єднання');
    }
  };

  if (isLoading) return <div className="text-center py-20 text-gray-500">Завантаження панелі керування...</div>;
  if (error) return <div className="text-center py-20 text-red-500">{error}</div>;

  return (
    <div className="max-w-6xl mx-auto py-10 px-4">
      <h1 className="text-3xl font-black text-brand-dark mb-8">Панель Адміністратора</h1>

      <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
        <div className="p-5 border-b border-gray-200 bg-gray-50">
          <h2 className="text-lg font-bold text-gray-800">Керування користувачами</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 text-xs uppercase tracking-wider text-gray-500 border-b border-gray-200">
                <th className="p-4 font-semibold">Ім'я</th>
                <th className="p-4 font-semibold">Email</th>
                <th className="p-4 font-semibold">Поточна роль</th>
                <th className="p-4 font-semibold">Статус</th>
                <th className="p-4 font-semibold text-right">Дії</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {usersList.map((u) => (
                <tr key={u.id} className="hover:bg-gray-50 transition-colors">
                  <td className="p-4 font-medium text-gray-900">{u.name}</td>
                  <td className="p-4 text-gray-600 text-sm">{u.email}</td>
                  <td className="p-4 text-sm text-gray-600">{u.role}</td>
                  <td className="p-4">
                    <span className={`inline-flex px-2 py-1 rounded-md text-xs font-bold ${u.isApproved ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                      {u.isApproved ? 'Активний' : 'Очікує модерації'}
                    </span>
                  </td>
                  <td className="p-4 text-right space-x-2">
                    {!u.isApproved && (
                      <>
                        <button
                          onClick={() => handleApprove(u.id, 'Журналіст')}
                          className="bg-brand-blue text-white text-xs px-3 py-1.5 rounded hover:opacity-90 transition-opacity"
                        >
                          Зробити Журналістом
                        </button>
                        <button
                          onClick={() => handleApprove(u.id, 'Автор')}
                          className="bg-gray-800 text-white text-xs px-3 py-1.5 rounded hover:opacity-90 transition-opacity"
                        >
                          Зробити Автором
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
              {usersList.length === 0 && (
                <tr>
                  <td colSpan="5" className="p-8 text-center text-gray-500">
                    Користувачів поки немає
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
