import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { usePermissions } from '../../hooks/usePermissions';

const ForumHome = () => {
    const { canUseForum } = usePermissions();
    const [topics, setTopics] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

    useEffect(() => {
        const fetchTopics = async () => {
            setIsLoading(true);
            try {
                const response = await fetch(`${API_URL}/forum/topics`);
                if (response.ok) {
                    const data = await response.json();
                    setTopics(data);
                }
            } catch (error) {
                console.error("Помилка завантаження тем форуму:", error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchTopics();
    }, [API_URL]);

    return (
        <div className="max-w-6xl mx-auto py-8 px-4 space-y-6">
            <div className="border-b border-gray-200 pb-4">
                <h1 className="text-3xl font-black text-gray-900 tracking-tight">Міський Форум</h1>
                <p className="text-sm text-gray-500 mt-1">Відкритий простір для обговорень, ідей та запитань від жителів.</p>
            </div>

            {!canUseForum ? (
                <div className="bg-amber-50 border border-amber-200 p-6 rounded-2xl text-center">
                    <p className="text-amber-800 font-medium">Форум доступний лише для авторизованих користувачів.</p>
                    <p className="text-xs text-amber-600 mt-1">Будь ласка, увійдіть у свій акаунт, щоб створювати теми та брати участь у дискусіях.</p>
                </div>
            ) : (
                <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
                    <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                        <span className="text-sm font-bold text-gray-600 uppercase tracking-wider">Актуальні гілки обговорень</span>
                        <button className="bg-brand-dark text-white text-xs font-semibold px-4 py-2.5 rounded-lg hover:opacity-90 transition-opacity">
                            + Створити тему
                        </button>
                    </div>

                    {isLoading ? (
                        <div className="p-10 text-center text-gray-500">Завантаження форуму...</div>
                    ) : topics.length === 0 ? (
                        <div className="p-10 text-center text-gray-500">На форумі ще немає створених тем. Будьте першим!</div>
                    ) : (
                        <div className="divide-y divide-gray-100">
                            {topics.map((topic) => (
                                <div key={topic.id} className="p-4 hover:bg-gray-50 transition-colors flex justify-between items-center gap-4">
                                    <div>
                                        <Link to={`/forum/${topic.id}`}>
                                            <h3 className="font-semibold text-gray-900 hover:text-brand-blue cursor-pointer text-base transition-colors">
                                                {topic.title}
                                            </h3>
                                        </Link>
                                        <p className="text-xs text-gray-400 mt-1">Автор: <span className="font-medium">@{topic.author}</span></p>
                                    </div>
                                    <div className="text-center px-4 py-1.5 bg-brand-light rounded-lg min-w-[80px]">
                                        <span className="block text-sm font-bold text-brand-blue">{topic.replies || 0}</span>
                                        <span className="text-[10px] uppercase font-bold text-brand-accent tracking-tight">відповідей</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default ForumHome;
