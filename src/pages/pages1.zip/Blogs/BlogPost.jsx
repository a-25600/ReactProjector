import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

const BlogPost = () => {
    const { id } = useParams(); // Отримуємо ID з URL
    const [blog, setBlog] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

    useEffect(() => {
        const fetchBlog = async () => {
            setIsLoading(true);
            try {
                // Очікуваний C# Endpoint: [HttpGet] Route("api/blogs/{id}")
                const response = await fetch(`${API_URL}/blogs/${id}`);

                if (!response.ok) {
                    if (response.status === 404) {
                        throw new Error('Статтю не знайдено');
                    }
                    throw new Error('Помилка завантаження статті');
                }

                const data = await response.json();
                setBlog(data);
            } catch (err) {
                console.error(err);
                setError(err.message);
            } finally {
                setIsLoading(false);
            }
        };

        fetchBlog();
    }, [id, API_URL]);

    if (isLoading) {
        return <div className="text-center py-20 text-gray-500 animate-pulse">Завантаження статті...</div>;
    }

    if (error || !blog) {
        return (
            <div className="max-w-3xl mx-auto py-20 text-center">
                <span className="text-4xl block mb-4">📄</span>
                <h2 className="text-2xl font-bold text-gray-800 mb-4">{error || 'Статтю не знайдено'}</h2>
                <Link to="/blogs" className="text-brand-blue font-medium hover:underline">
                    Повернутися до списку блогів
                </Link>
            </div>
        );
    }

    return (
        <article className="max-w-3xl mx-auto py-10 px-4">
            {/* Навігація назад */}
            <Link to="/blogs" className="inline-flex items-center text-sm text-gray-500 hover:text-brand-blue transition-colors mb-8">
                <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Усі блоги
            </Link>

            {/* Шапка блогу */}
            <header className="mb-10">
                <h1 className="text-3xl md:text-4xl font-black text-brand-dark leading-tight mb-6">
                    {blog.title}
                </h1>

                <div className="flex items-center justify-between border-y border-gray-200 py-4">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-brand-light rounded-full flex items-center justify-center text-brand-blue font-bold text-lg">
                            {blog.author ? blog.author[0] : 'А'}
                        </div>
                        <div>
                            <p className="font-bold text-brand-dark">{blog.author}</p>
                            <p className="text-sm text-gray-500">{blog.role} • {blog.date}</p>
                        </div>
                    </div>

                    <button className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-50 rounded-full border border-gray-200 hover:bg-red-50 hover:border-red-100 hover:text-red-600 transition-all text-sm text-gray-600">
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                        </svg>
                        {blog.likes || 0}
                    </button>
                </div>
            </header>

            {/* Текст статті */}
            <div className="prose prose-lg max-w-none text-gray-800 leading-relaxed mb-12">
                <p className="text-xl text-gray-600 italic border-l-4 border-brand-blue pl-4 mb-8">
                    {blog.excerpt}
                </p>
                <p className="whitespace-pre-line">
                    {blog.content}
                </p>
            </div>

        </article>
    );
};

export default BlogPost;
