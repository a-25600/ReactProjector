import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { usePermissions } from '../../hooks/usePermissions';

const BlogList = () => {
    const { canWriteBlog } = usePermissions();
    const [blogs, setBlogs] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

    useEffect(() => {
        const fetchBlogs = async () => {
            setIsLoading(true);
            try {
                const response = await fetch(`${API_URL}/blogs`);
                if (!response.ok) throw new Error('Не вдалося завантажити блоги');

                const data = await response.json();
                setBlogs(data);
            } catch (err) {
                console.error("Помилка:", err);
                setError(err.message);
            } finally {
                setIsLoading(false);
            }
        };

        fetchBlogs();
    }, [API_URL]);

    return (
        <div className="max-w-6xl mx-auto py-8 px-4 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-gray-200 pb-4 gap-4">
                <div>
                    <h1 className="text-3xl font-black text-gray-900 tracking-tight">Авторські Блоги</h1>
                    <p className="text-sm text-gray-500 mt-1">Думки експертів, аналітика та суб'єктивні погляди на події.</p>
                </div>

                {canWriteBlog && (
                    <Link
                        to="/author-workspace"
                        className="bg-brand-blue text-white font-medium text-sm px-5 py-2.5 rounded-lg hover:opacity-90 transition-opacity shrink-0"
                    >
                        Написати статтю
                    </Link>
                )}
            </div>

            {isLoading ? (
                <div className="text-center py-20 text-gray-500 animate-pulse">Завантаження блогів...</div>
            ) : error ? (
                <div className="text-center py-10 text-red-500">{error}</div>
            ) : blogs.length === 0 ? (
                <div className="text-center py-20 bg-gray-50 rounded-2xl border border-gray-200">
                    <p className="text-gray-500">Поки що немає опублікованих блогів.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {blogs.map((blog) => (
                        <div key={blog.id} className="border border-gray-200 rounded-2xl p-6 bg-white hover:shadow-md transition-shadow flex flex-col justify-between">
                            <div>
                                <div className="flex items-center gap-3 mb-4">
                                    <div className="w-10 h-10 bg-brand-light rounded-full flex items-center justify-center text-brand-blue font-bold text-sm">
                                        {blog.author ? blog.author[0] : 'А'}
                                    </div>
                                    <div>
                                        <h4 className="text-sm font-semibold text-gray-800">{blog.author}</h4>
                                        <p className="text-xs text-gray-500">{blog.role} • {blog.date}</p>
                                    </div>
                                </div>

                                <Link to={`/blogs/${blog.id}`}>
                                    <h3 className="text-xl font-bold text-gray-900 mb-3 hover:text-brand-blue transition-colors">
                                        {blog.title}
                                    </h3>
                                </Link>

                                <p className="text-sm text-gray-600 leading-relaxed mb-5 line-clamp-3">
                                    {blog.excerpt || blog.content?.substring(0, 150) + '...'}
                                </p>
                            </div>

                            <div className="flex justify-between items-center text-xs text-gray-500 pt-4 border-t border-gray-100">
                                <span className="flex items-center gap-1">
                                    <svg className="w-4 h-4 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                                        <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                                    </svg>
                                    {blog.likes || 0}
                                </span>
                                <Link to={`/blogs/${blog.id}`} className="text-brand-blue font-medium hover:underline">
                                    Читати повністю →
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default BlogList;
